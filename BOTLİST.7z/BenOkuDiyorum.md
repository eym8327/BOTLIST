# Çalınması Yasaktır

<img src="https://cdn.discordapp.com/attachments/726744679454081125/728555214021460028/a_6963b2073bea1582c1d3e4401db19c2f.gif">



**Kolpaçino Ogün :D**

- EMEGE SAYGI 

- Discord Adresımız : [TIKLA](https://discord.gg/kobs)

- Hazırlayan :  ``Forcex``
